import { Component } from 'react';
import  { connect }  from 'react-redux';
import { getAcivityLevel } from '../redux/ActivityLevel/action';
import Dashbaord from './Dashboard';
 

class App extends Component {
    render(){
        return(
            <Dashbaord {...this.props} />   
        )
    }

}


const mapStateToProps = state => {
    return{
        activityLevel : state.activityLevel
    }
}

const mapPropsToDispatch = dispatch => {
    return {
        onRequestActivityLevel : () => dispatch(getAcivityLevel()),
    }
}

export default connect(mapStateToProps , mapPropsToDispatch)(App)