import { useEffect,useState } from 'react';
import { connect } from 'react-redux';
import { calculateAcivityLevel } from '../redux/CalculateActivityLevel/action';


const Dashbaord = (props) => {
    const [userWeight, setuserWeight] = useState(0);
    const [bodyFat, setbodyFat] = useState(0);
    const [activityLevel,setActivityLevel] = useState('');

    useEffect(() => {
        props.onRequestActivityLevel();
    },[]);

    const onSumbitHandler = () => {
        let data = {
            weight : userWeight,
            bodyFat : bodyFat,
            activityLevel : activityLevel
        }
        props.onRequestCalculateActivityLevel(data);
    }

    return(
        <div className="container-fluid">
            <div className="col-lg-12">
                    <h4 className="heading">Total Daily Energy Expenditure</h4>
            </div>
            <div className="container">
                    <form className="col-lg-12">
                        <div className="form-group">
                            <div className="col-md-12">
                                <label htmlFor="exampleInputEmail1">Weight</label>
                                <input type="text" value={userWeight} onChange={(e) => setuserWeight(e.target.value.trim())} className="form-control" placeholder="Weight" />
                            </div>
                            <div className="col-md-12">
                                <label htmlFor="exampleInputEmail1">Body Fat</label>
                                <input type="text" value={bodyFat} onChange={(e) => setbodyFat(e.target.value.trim())} className="form-control" placeholder="Body Fat" />   
                            </div>
                            <div className="col-md-12">
                                    <select className="form-control form-control-lg" onChange={(e) => setActivityLevel(e.target.value)}>
                                        {
                                            props.activityLevel.activityLevel.length > 0 ?
                                            props.activityLevel.activityLevel.map((element,index) => {
                                                return <option key={index} value={element}>{element}</option>
                                            })
                                            :
                                            <option></option>
                                        }
                                    </select>
                             </div>    
                           </div>
                           <div className="col-lg-12">
                               <button  type="button" className="btn btn-primary" onClick={onSumbitHandler}>Submit</button>
                           </div> 
                    </form>
            </div>
        </div>
    )
}

const mapStateToProps = state => {
    return{
        BMR: state.CalculateActivityLevel,
        TDEE : state.CalculateActivityLevel,
    }
}

const mapPropsToDispatch = dispatch => {
    return {
        onRequestCalculateActivityLevel : (data) => dispatch((calculateAcivityLevel(data))),
    }
}

export default connect(mapStateToProps,mapPropsToDispatch)(Dashbaord)