import { FETCH_ACTIVITY_LEVEL , FAILURE_ACTIVITY_LEVEL , SUCCESS_ACTIVITY_LEVEL } from  './constants';
import axios from 'axios';



export const getAcivityLevel  = () => (disaptch) => {
    disaptch({type: FETCH_ACTIVITY_LEVEL});
    axios.get('http://localhost:8000/api/activityLevel').then((response) => {
        disaptch({type: SUCCESS_ACTIVITY_LEVEL,payload: response.data.data});
    }).catch(err => {
        disaptch({type: FAILURE_ACTIVITY_LEVEL,payload: err});
    })  
} 