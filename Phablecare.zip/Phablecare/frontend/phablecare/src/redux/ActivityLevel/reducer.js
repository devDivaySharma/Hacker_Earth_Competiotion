import { FETCH_ACTIVITY_LEVEL , FAILURE_ACTIVITY_LEVEL , SUCCESS_ACTIVITY_LEVEL } from  './constants';

const intialStata = {
    activityLevel : [],
    isPending : false
}

export const reducer = (state=intialStata,action) => {
    switch (action.type) {
        case FETCH_ACTIVITY_LEVEL: return {...state, isPending: true }
        case SUCCESS_ACTIVITY_LEVEL: return {...state, isPending: false,activityLevel : action.payload }
        case FAILURE_ACTIVITY_LEVEL: return {...state, isPending: false,activityLevel : [] }
        default: return state
    }
}