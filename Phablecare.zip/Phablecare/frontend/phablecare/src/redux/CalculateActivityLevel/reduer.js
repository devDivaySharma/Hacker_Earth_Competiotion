import { FETCH_CALCULATE_ACTIVITY_LEVEL, SUCCESS_CALCULATE_ACTIVITY_LEVEL, FAILURE_CALCULATE_ACTIVITY_LEVEL } from  './constants';

const intialStata = {
    bmr : 0,
    isPending : false,
    tdee : 0
}

export const reducer = (state=intialStata,action) => {
    switch (action.type) {
        case FETCH_CALCULATE_ACTIVITY_LEVEL: return {...state, isPending: true }
        case SUCCESS_CALCULATE_ACTIVITY_LEVEL: return {...state, isPending: false,brm : action.payload.bmr,tdee : action.payload.tdee }
        case FAILURE_CALCULATE_ACTIVITY_LEVEL: return {...state, isPending: false,brm : 0,tdee : 0 }
        default: return state
    }
}