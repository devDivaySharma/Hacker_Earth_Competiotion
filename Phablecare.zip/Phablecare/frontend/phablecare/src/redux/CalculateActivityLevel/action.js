import { FETCH_CALCULATE_ACTIVITY_LEVEL, SUCCESS_CALCULATE_ACTIVITY_LEVEL, FAILURE_CALCULATE_ACTIVITY_LEVEL } from  './constants';
import axios from 'axios';



export const calculateAcivityLevel  = (data) => (disaptch) => {
    disaptch({type: FETCH_CALCULATE_ACTIVITY_LEVEL});
    axios.post('http://localhost:8000/api/calculateActivityLevel',data).then((response) => {
        disaptch({type: SUCCESS_CALCULATE_ACTIVITY_LEVEL,payload: response.data.data});
    }).catch(err => {
        disaptch({type: FAILURE_CALCULATE_ACTIVITY_LEVEL,payload: err});
    })  
} 