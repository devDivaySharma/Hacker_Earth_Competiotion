import React,{ Component } from 'react';
import axios from 'axios';
import Blog from './Blog';
import SearchBlog from './SearchBlog';


/* Container Page Fetch Blogs and Also work when want to search blogs*/
class BlogContainer extends Component {
    constructor(props){
        super(props);
        this.state = {
            blogs : [],
            search : '',
            isLoading: true
        }
    }

    /* Fetch Blogs After Page Load*/
    componentDidMount(){
        this.fetchPost();
    }

    /* Fetch Post and Show Posts by updaeting state*/
    fetchPost = () => {
        axios.get('https://jsonplaceholder.typicode.com/posts').then((response) => {
            if(response.status === 200){
                this.setState({
                    blogs : response.data,
                    isLoading : false
                });
            }else{
                alert('Sorry Unable to fetch Blogs, Please Try Again!!!')    
            }
        }).catch((err) => {
            alert('Sorry Unable to fetch Blogs, Please Try Again!!!')
        })
    }

    /*Handle and Update Search State*/
    handleSearch = (event) => {
        this.setState({
            search : event.target.value
        })
    }

    /* Filter Blogs*/
    filterBlogs = (blogs,search) => {
        return blogs.filter((blog) =>  blog.title.toLowerCase().includes(search.toLowerCase()))
    }

    render(){
        const { blogs , search , isLoading} = this.state;
        const filterBlogs = this.filterBlogs(blogs,search);
        return(
            <div>
                   <SearchBlog handleSearch={this.handleSearch}/> 
                   <Blog blogs={filterBlogs} isLoading={isLoading}/>  
            </div>
        )
    }
}

export default BlogContainer