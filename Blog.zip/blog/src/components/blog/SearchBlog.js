import React from 'react';
import { useHistory } from 'react-router-dom';


/* This page is related to Search Blog and Redirect to Create Blog Page*/
const SearchBlog = ({handleSearch}) => {
   let history = useHistory(); 
   let handleRoute = () => {
        history.push("/blog/new")
    }
    return(
        <div className="search-container text-center">
            <div style={{display : "inline-flex"}}>
                <input onChange={handleSearch} className="text-box" type="text" placeholder="Search with Titile" />
                <div style={{margin: "10px"}} onClick={handleRoute}>Create Blog</div>
            </div>
        </div>
    )
}

export default SearchBlog
