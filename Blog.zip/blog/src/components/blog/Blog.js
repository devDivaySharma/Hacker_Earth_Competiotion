import React from 'react';

/* This Page concern With Blog Page to Show Blogs*/
const Blog = ({blogs,isLoading}) => {
    return(
            isLoading ?
            <div className="loader"></div> 
            :
            <div className="container">
                {
                    blogs.length ?
                    blogs.map((blog,index) => {
                        return <div key={index} className="cards">
                                <div className="card">
                                    <div className="card-container">
                                    <h4><b>{blog.title}</b></h4>
                                    <p>{blog.body}</p>
                                    </div>
                                </div>
                            </div>   
                    })
                    :
                    <p className="text-center f-18">Sorry No Blog Found</p>
                }
            </div>
    )
}

export default Blog