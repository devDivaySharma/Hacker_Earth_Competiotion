
import { CKEditor } from '@ckeditor/ckeditor5-react';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { useState } from 'react';
import axios from 'axios';
import { useHistory } from 'react-router-dom';

/* This page concern with Creating New Blog and also contains ckeditor*/
const NewBlog = () => {
    let history = useHistory();
    const [ post, setPost ]  = useState(''); 
    const onSubmit = () => {
        let body = {
            title : post,
            body : post,
            userId : 1
        }
        axios.post('https://jsonplaceholder.typicode.com/posts',body).then((response) => {
            history.push("/blogs");
        }).catch((err) => {
            alert('Please Try Again To Post Blog');
        })  
    }
    return(
        <div>
            <h4 className="text-center"> New Blog</h4>
             <CKEditor
                    editor={ ClassicEditor }
                    data=""
                    onReady={ editor => {
                        // You can store the "editor" and use when it is needed.
                        console.log( 'Editor is ready to use!', editor );
                    } }
                    onChange={ ( event, editor ) => {
                        const data = editor.getData();
                        setPost(data)
                    } }
                />
                <button onClick={onSubmit}>Submit Post</button>
        </div>
    )
}

export default NewBlog