import './App.css';
import { Route , BrowserRouter , Switch} from 'react-router-dom';
import ResumePage  from './components/resume/ResumePage';
import BlogContainer from './components/blog/BlogContaniner';
import NewBlog from './components/blog/NewBlog';
function App() {
  return (
    <div className="body">
      {/* All Routeing Should be define here*/}
         <BrowserRouter>
           <Switch>
                <Route exact path="/blog/new" component={NewBlog} />
                <Route path="/blogs" component={BlogContainer} />
                <Route path="/" component={ResumePage} />
           </Switch>
        </BrowserRouter> 
    </div>
  );
}

export default App;
