import ResumePage from './resumePage';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import ReactPage from './linkPages/react';
import JavascriptPage from './linkPages/javascriptPage';
import AngularPage from './linkPages/angular';
import NodePage from './linkPages/node';
import MicroServiceArchitecturePage from './linkPages/mircroService';
import MongoDbPage from './linkPages/mongoDb';
import FunctionalProgrammingPage from './linkPages/functionalProgramming';


const Routeing = () => {
    return (
        <Switch>
            <Route exact path="/">
                <ResumePage />
            </Route>
            <Route path="/React">
                <ReactPage />
            </Route>
            <Route path="/javascript">
                <JavascriptPage />
            </Route>
            <Route path="/node">
                <NodePage />
            </Route>
            <Route path="/angular">
                <AngularPage />
            </Route>
            <Route path="/microservice">
                <MicroServiceArchitecturePage />
            </Route>
            <Route path="/mongo">
                <MongoDbPage />
            </Route>
            <Route path="/functionalProgramming">
                <FunctionalProgrammingPage />
            </Route>
        </Switch>
    )
}

export default Routeing