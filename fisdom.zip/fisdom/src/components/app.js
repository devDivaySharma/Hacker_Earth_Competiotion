import React from 'react';
import Header from './header';
import Footer from './footer';
import {BrowserRouter as Router} from 'react-router-dom';
import Routeing from './routeing';

class App extends React.Component {
    render(){
        return(
            <>
            <Header />
                <Router>
                        <Routeing />         
                </Router>
            <Footer />
            </>
        )
    }
}

export default App