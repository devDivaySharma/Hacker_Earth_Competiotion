
/* This Page Concern with Resume Page */
const ResumePage = () => {  
    return (
        <>
            <div className="resume header">
                <h5 className="text-center f-18">Divay Sharma</h5>
                <p className="text-center f-20"><span className="f-15">(+91) - 7737088705</span> | <span className="f-15">divaysharma11@gmail.com</span> | <span className="f-15">Gurugram</span></p>
            </div>
            <hr className="hr_line" />
            <div className="section">
                <h5 className="f-18">Professional Summary</h5>
                <ul>
                    <li><p className="f-15">Having 3.5 year of experience in developing SPA Web Applications,Mobile Applications, Microservice, Command Line Application and SDK Package’s .</p></li>
                    <li><p className="f-15">Working on vanilla js with es6 and latest features.</p></li>
                    <li><p className="f-15">Experience in working with React with state,props and lifecycle hooks</p></li>
                    <li><p className="f-15">Experience in working with Angular 2+ modules,services,templates,directives, and dependency Injection to create a SPA.</p></li>
                    <li><p className="f-15">Extensive knowledge in Mysql and MongoDb concepts.</p></li>
                    <li><p className="f-15">Experience in Unit Testing(UIT)</p></li>
                    <li><p className="f-15">Extensive experience working under Agile methodologies environment.</p></li>
                    <li><p className="f-15">Knowledge of Docker,Nginx and Setup linux based server for Applications.</p></li>
                </ul>
            </div>
            <hr className="hr_line" />
            <div className="section">
                <h5 className="f-18">Skills</h5>
                <ul>
                    <li><p className="f-15"><b>Languages :-</b> Javascript,Data Structure,Typescript,Html,Css,Jquery,Bootstrap(3,4),Material-UI,React-Strap</p></li>
                    <li><p className="f-15"><b>FrameWorks :- </b> Angular 2,5,(+7),React Js, Express</p></li>
                    <li><p className="f-15"><b>Unit Test Framework :- </b> Mocha,Chai,Jasmine,Karma and Enzyme</p></li>
                </ul>
            </div>
            <hr className="hr_line" />
            <div className="section">
                <h5 className="f-18">Experience</h5>
                <h6 className="f-17">GSPANN Technologies Inc. , Gurugram— Software Developer</h6>
                <span className="f-12">Oct 2020 - Present</span>
                <p className="">William Sonoma Inc.</p>
                <ul>
                    <li>Customer facing Application Portal developed on React Js.</li>
                    <li>Api’s for MicroService Architecture On Node Js.</li>
                </ul>

                <h6 className="f-17">Akeo Software Solutions Pvt. Ltd. , Jaipur — Software Developer</h6>
                <span className="f-12">July 2018 - Sept 2020</span>
                <p className="">Miris Exact ( SPA with Different Viewers into Single Platform )</p>
                <ul>
                    <li>Developed Api’s using Node js.</li>
                    <li>Worked with Postgres.</li>
                    <li>Implement Client-side using Angular-8.</li>
                    <li>Implement Google Cloud Storage and Google Maps.</li>
                </ul>
                <p className="">Wakandi ( Crypto Currency Implementation with HyperLedger Fabric )</p>
                <ul>
                    <li>Developed Api’s using Node js.</li>
                    <li>Developed a npm package and cli application.</li>
                    <li>Used git version controlling.</li>
                    <li>Worked on the Microservice Architecture for Authentication of user.</li>
                </ul>
                <h6 className="f-17">Pericent Technologies Pvt. Ltd. , Jaipur — Software Developer</h6>
                <span className="f-12">Sept 2017 - April 2018</span>
                <p className="">Worked on their Website and also on Bpm Product.</p>
            </div>
            <hr className="hr_line" />
            <div className="section">
                <h5 className="f-18">EDUCATION</h5>
                <h6 className="f-17">Mohanlal Sukhadia University, Udaipur— M.C.A</h6>
                <span className="f-12">Aug 2014 - Sept 2017</span>
                <br />
                <h6 className="f-17">University Of Rajasthan, Jaipur— B.C.A</h6>
                <span className="f-12">Aug 2010 - Sept 2013</span>
                <br/>
            </div>
            <hr className="hr_line" />
            <div className="section">
                <h5 className="f-18">Award and Honor</h5>
                <h6 className="f-15"><b>2019 :- </b> Hard Working Employee Recognition for Miris Exact for the year.</h6>
                <br />
                <h6 className="f-15"><b>2014 :- </b> Secured 40 rank in RMCAAT Exam(Rajasthan MCA Admission Test).</h6>
                <br/>
            </div>
        </>
    )
}

export default ResumePage