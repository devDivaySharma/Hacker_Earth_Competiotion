import axios from 'axios';

const FetchData = () => {
    return(
        axios.get("https://baconipsum.com/api/?type=meat-and-filler&paras=10").then((response) => {
                return response.data;
            }).catch((err) => {
                return err;
        })
    )
}

export default FetchData;