import FetchData from '../fetch/fetch';
import {useState , useEffect } from 'react';

const NodePage = () => {
    const [isLoading , setLoading] = useState(true);
    const [skillData , setSkillData] = useState({});


    useEffect(() => {
        FetchData().then((data) => {
            setSkillData(data);
        }).catch((err) => {
            setSkillData(err);   
        })
        setLoading(false);
    },[])

    return(
        isLoading ? 
        <div className="loader"></div>
        :
        <div className="container">
            <h1 className="text-center">Node Js Page</h1>
            {
                skillData.length ?
                skillData.map((skill,index) => {
                    return <p key={index}>{skill}</p>
                })
                :
                <p className="text-center f-18">Sorry No Data Found</p>
            }
        </div>
    )
}

export default NodePage;