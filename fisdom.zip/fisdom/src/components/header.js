import { BrowserRouter as Router , NavLink } from 'react-router-dom';

const Header  = () => {
    return(
        <div className="nav">
              <input type="checkbox" id="nav-check"></input>
              <div className="nav-header">
                    <div className="nav-title">
                        <Router>
                            <NavLink to="/" className="nav-link">React Application</NavLink>
                        </Router>
                    </div>
                </div>
                <div className="nav-btn">
                    <label htmlFor="nav-check">
                    <span></span>
                    <span></span>
                    <span></span>
                    </label>
                </div>
                <div className="nav-links">
                    <Router>
                            <NavLink to="/javascript">Javascript</NavLink>
                            <NavLink to="/functionalProgramming">Functional Programming</NavLink>
                            <NavLink to="/React">React</NavLink>
                            <NavLink to="/angular">Angular +2</NavLink>
                            <NavLink to="/node">Node</NavLink>
                            <NavLink to="/mongo">MongoDb</NavLink>
                            <NavLink to="/microservice">MicroService Architecture</NavLink>
                    </Router>
                </div>
        </div>
    )
}

export default Header

