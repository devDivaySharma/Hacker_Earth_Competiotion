import { BrowserRouter as Router , Link } from 'react-router-dom'; 

const Footer  = () => {
    return(
        <Router>
        <div className="footer">
            <div className="contain">
            <div className="col">
                <h1>Route</h1>
                <ul>
                            <Link to="/javascript" className="nav-link"><li>Javascript</li></Link>
                            <Link to="/functionalProgramming" className="nav-link"><li>Functional Programming</li></Link>
                            <Link to="/React" className="nav-link"><li>React</li></Link>
                            <Link to="/angular" className="nav-link"><li>Angular +2</li></Link>
                            <Link to="/node" className="nav-link"><li>Node</li></Link>
                            <Link to="/mongo" className="nav-link"><li>MongoDb</li></Link>
                            <Link to="/microservice" className="nav-link"><li>MicroService Architecture</li></Link>
                </ul>
            </div>
            <div className="col">
            <h1>Route</h1>
                <ul>
                            <Link to="/javascript" className="nav-link"><li>Javascript</li></Link>
                            <Link to="/functionalProgramming" className="nav-link"><li>Functional Programming</li></Link>
                            <Link to="/React" className="nav-link"><li>React</li></Link>
                            <Link to="/angular" className="nav-link"><li>Angular +2</li></Link>
                            <Link to="/node" className="nav-link"><li>Node</li></Link>
                            <Link to="/mongo" className="nav-link"><li>MongoDb</li></Link>
                            <Link to="/microservice" className="nav-link"><li>MicroService Architecture</li></Link>
                </ul>
            </div>
            <div className="col">
            <h1>Route</h1>
                <ul>
                            <Link to="/javascript" className="nav-link"><li>Javascript</li></Link>
                            <Link to="/functionalProgramming" className="nav-link"><li>Functional Programming</li></Link>
                            <Link to="/React" className="nav-link"><li>React</li></Link>
                            <Link to="/angular" className="nav-link"><li>Angular +2</li></Link>
                            <Link to="/node" className="nav-link"><li>Node</li></Link>
                            <Link to="/mongo" className="nav-link"><li>MongoDb</li></Link>
                            <Link to="/microservice" className="nav-link"><li>MicroService Architecture</li></Link>
                </ul>
            </div>
            <div className="col">
            <h1>Route</h1>
                <ul>
                            <Link to="/javascript" className="nav-link"><li>Javascript</li></Link>
                            <Link to="/functionalProgramming" className="nav-link"><li>Functional Programming</li></Link>
                            <Link to="/React" className="nav-link"><li>React</li></Link>
                            <Link to="/angular" className="nav-link"><li>Angular +2</li></Link>
                            <Link to="/node" className="nav-link"><li>Node</li></Link>
                            <Link to="/mongo" className="nav-link"><li>MongoDb</li></Link>
                            <Link to="/microservice" className="nav-link"><li>MicroService Architecture</li></Link>
                </ul>
            </div>
            <div className="col">
            <h1>Route</h1>
                <ul>
                            <Link to="/javascript" className="nav-link"><li>Javascript</li></Link>
                            <Link to="/functionalProgramming" className="nav-link"><li>Functional Programming</li></Link>
                            <Link to="/React" className="nav-link"><li>React</li></Link>
                            <Link to="/angular" className="nav-link"><li>Angular +2</li></Link>
                            <Link to="/node" className="nav-link"><li>Node</li></Link>
                            <Link to="/mongo" className="nav-link"><li>MongoDb</li></Link>
                            <Link to="/microservice" className="nav-link"><li>MicroService Architecture</li></Link>
                </ul>
            </div>
            <div className="col social">
                <h1>Designed By </h1>
              <ul>
                <Link to="/" className="nav-link"><li>@Divay Sharma</li></Link>
              </ul>  
            </div>
            </div>
        </div>
        </Router>
    )
}

export default Footer

